<!DOCTYPE html>
<html lang="en">
<head>
	<title>Home</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=divice-width, initial-scale=1" >
	 <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	 
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
</head>
<body>
	<?php 
include('connect.php') 
	?>
<div class="container">
	<div class="jumbotron">
		<h1>WELCOME TO HOMEPAGE</h1>
		<nav class="navbar navbar-inverse">
			<div class="container-fluid">
				<ul class="nav navbar-nav">
					<li><a href="">VIEW</a></li>
					<li><a href="profile.php">PROFILE</a></li>
					<li><a href="edit.php">EDIT</a></li>
				</ul>
			</div>
		</nav>
	</div>
</div>
 
</body>
</html>
