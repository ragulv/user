<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=divice-width, initial-scale=1" >
	 <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	 <link rel="stylesheet" href="assets/css/style.css">
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
</head>
<body>
	<?php 
include('connect.php') 
	?>
<div class="container">
<form role="form" method="post" action="insert.php">
		<div class="form-group row">
			<label for="inputName" class="col-sm-2 col-form-label">Name</label>
			<div class="col-sm-9">
				<input type="text" class="form-control" id="inputName" name="name" placeholder="Name" autocomplete="on">
			</div>
			

			<div>
			<label for="inputCompany" class="col-sm-2 col-form-label">Company</label>
			<div class="col-sm-9">
				<input type="text" class="form-control" id="inputCompany" name="company" placeholder="Company" autocomplete="on">
			</div>
			</div>
			<div>
			<label for="inputAddress1" class="col-sm-2 col-form-label">Address1</label>
			<div class="col-sm-9">
				<input type="text" class="form-control" id="inputAddress1" name="address1" placeholder="Address1" autocomplete="on">
			</div>
			</div>

			<div>
			<label for="inputAddress2" class="col-sm-2 col-form-label">Address2</label>
			<div class="col-sm-9">
				<input type="text" class="form-control" id="inputAddress2" name="address2" placeholder="Address2" autocomplete="on">
			</div>
			</div>
			<div>
			<label for="inputCity" class="col-sm-2 col-form-label">City</label>
			<div class="col-sm-9">
				<input type="text" class="form-control" id="inputCity" name="city" placeholder="City" autocomplete="on">
			</div>
			</div>
			<div>
			<label for="inputState" class="col-sm-2 col-form-label">State</label>
			<div class="col-sm-9">
				<input type="text" class="form-control" id="inputState" name="state" placeholder="State" autocomplete="on">
			</div>
			</div>
			
			<div>
			<label for="inputPin_code" class="col-sm-2 col-form-label">Pin code</label>
			<div class="col-sm-9">
				<input type="text" class="form-control" id="inputPin_code" name="pin_code" placeholder="Pin code" autocomplete="on">
			</div>
			</div>
			<div>
			<label for="inputPhone_no" class="col-sm-2 col-form-label">Phone no</label>
			<div class="col-sm-9">
				<input type="text" class="form-control" id="inputPhone_no" name="phone_no" placeholder="Phone no" autocomplete="on">
			</div>
			</div>
		<div>
			<label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
			<div class="col-sm-9">
				<input type="text" class="form-control" id="inputEmail" name="email" placeholder="Email" autocomplete="on" required>
			</div>
			</div>
		<div>
			<label for="inputUser" class="col-sm-2 col-form-label">Username</label>
			<div class="col-sm-9">
				<input type="text" class="form-control" id="inputUser" name="username" placeholder="username" autocomplete="on" required>
			</div>
		</div>		
		<div>
			<label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
			<div class="col-sm-9">
				<input type="password" class="form-control" id="inputPassword" name="password" placeholder="Password" autocomplete="on" required>
			</div>
		</div>
		<div>
			<label for="psw-repeat" class="col-sm-2 col-form-label">Repeat Password</label>
			<div class="col-sm-9">
   				 <input type="password" class="form-control" id="psw-repeat" placeholder="Repeat Password" name="psw-repeat" required>
   			</div>
   		</div>
	</div>
		<div>
			<div >
				<input type="submit" value="Submit" name="submit" class="btn btn-success"/>
			</div>
			</div>	
				
	</form>
	</div>
</body>
</html>
