<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=divice-width, initial-scale=1" >
	 <link rel="stylesheet" href="assets/css/bootstrap.min.css">
	 <link rel="stylesheet" href="assets/css/style.css">
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
</head>
<body>
	
<h2><?php 
      /* Error Notification */
      if(!empty($_GET['error']) && $_GET['error'] == 1){
        echo 'Wrong username & password!';
      }


      if(!empty($_GET['error']) && $_GET['error'] == 2){
        echo 'Please login to continue!';
      }
      if (@$_GET['success']==1) {
        echo 'Profile created successfully';}
      ?></h2>

  <div class="container">
    
<form action="checklogin.php" method="POST">
  
  <div class="container-fluid">
    <div class="form-group row">
      <div class="col-sm-9">
    <label for="username"><b>Username</b></label>
    <input type="text"  placeholder="Enter Username" name="username" >

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" >

    <button type="submit">Login</button>
    
   <h2 style="text-align: center"> or </h2>
 

  <div>
    <button style="background-color: #ff6666"><a href="signup.php?">Sign Up</a></button>
     </div>
  </div>
</div>
</div>
</form>
</div>

</body>
</html>